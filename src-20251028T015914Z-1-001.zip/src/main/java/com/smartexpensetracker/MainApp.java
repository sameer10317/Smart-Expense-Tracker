package com.smartexpensetracker;

import com.smartexpensetracker.db.DatabaseHelper;
import com.smartexpensetracker.manager.ExpenseManager;
import com.smartexpensetracker.manager.BudgetManager;
import com.smartexpensetracker.model.Expense;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.chart.PieChart;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.time.LocalDate;
import java.util.List;

public class MainApp extends Application {

    private ExpenseManager expenseManager;
    private BudgetManager budgetManager;
    private ObservableList<Expense> expenseObservableList;
    private PieChart pieChart; // ✅ declare pieChart globally

    @Override
    public void start(Stage primaryStage) throws Exception {
        System.out.println("🚀 Starting Smart Expense Tracker...");

        // Initialize DB safely
        try {
            DatabaseHelper.init();
            if (DatabaseHelper.getConnection() == null || !DatabaseHelper.getConnection().isValid(2)) {
                throw new RuntimeException("❌ DB connection failed — DatabaseHelper returned null or invalid connection!");
            }
            System.out.println("✅ Database connected and verified.");
        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Database Error", "Could not connect to database: " + e.getMessage());
            return; // Stop launch
        }

        expenseManager = new ExpenseManager();
        budgetManager = new BudgetManager();

        primaryStage.setTitle("Smart Expense Tracker");

        // ---------- FORM SECTION ----------
        TextField amountField = new TextField();
        amountField.setPromptText("Amount");

        ComboBox<String> categoryBox = new ComboBox<>();
        categoryBox.getItems().addAll("Food", "Travel", "Bills", "Shopping", "Other");
        categoryBox.setValue("Food");

        DatePicker datePicker = new DatePicker(LocalDate.now());
        TextField noteField = new TextField();
        noteField.setPromptText("Note");

        // ✅ move pieChart declaration before button (so it's known)
        pieChart = new PieChart();
        pieChart.setTitle("Expenses by Category");

        Button addBtn = new Button("Add Expense");
        addBtn.setOnAction(e -> {
            try {
                double amount = Double.parseDouble(amountField.getText());
                String category = categoryBox.getValue();
                LocalDate date = datePicker.getValue();
                String note = noteField.getText();

                Expense ex = new Expense(0, amount, category, note, date);
                expenseManager.addExpense(ex);

                refreshExpenses();
                updateChart(pieChart);

                amountField.clear();
                noteField.clear();
            } catch (Exception ex) {
                ex.printStackTrace();
                showAlert("Error", "Invalid input: " + ex.getMessage());
            }
        });

        HBox form = new HBox(8, amountField, categoryBox, datePicker, noteField, addBtn);
        form.setPadding(new Insets(10));

        // ---------- TABLE SECTION ----------
        TableView<Expense> table = new TableView<>();
        TableColumn<Expense, Integer> idCol = new TableColumn<>("ID");
        idCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        TableColumn<Expense, Double> amtCol = new TableColumn<>("Amount");
        amtCol.setCellValueFactory(new PropertyValueFactory<>("amount"));
        TableColumn<Expense, String> catCol = new TableColumn<>("Category");
        catCol.setCellValueFactory(new PropertyValueFactory<>("category"));
        TableColumn<Expense, String> noteCol = new TableColumn<>("Note");
        noteCol.setCellValueFactory(new PropertyValueFactory<>("note"));
        TableColumn<Expense, String> dateCol = new TableColumn<>("Date");
        dateCol.setCellValueFactory(new PropertyValueFactory<>("date"));

        table.getColumns().addAll(idCol, amtCol, catCol, noteCol, dateCol);

        expenseObservableList = FXCollections.observableArrayList();
        table.setItems(expenseObservableList);

        // ---------- CHART + REFRESH ----------
        Button refreshBtn = new Button("Refresh");
        refreshBtn.setOnAction(e -> {
            try {
                refreshExpenses();
                updateChart(pieChart);
            } catch (Exception ex) {
                ex.printStackTrace();
                showAlert("Error", "Could not load data from database: " + ex.getMessage());
            }
        });

        VBox center = new VBox(8, table, refreshBtn);
        center.setPadding(new Insets(10));
        VBox right = new VBox(8, pieChart);
        right.setPadding(new Insets(10));
        right.setPrefWidth(300);

        HBox main = new HBox(8, center, right);
        VBox root = new VBox(8, form, main);

        Scene scene = new Scene(root, 900, 600);
        primaryStage.setScene(scene);
        primaryStage.show();

        // ---------- INITIAL LOAD ----------
        try {
            refreshExpenses();
            updateChart(pieChart);
            showAlert("Connected", "✅ Database Connected Successfully!");
        } catch (Exception ex) {
            ex.printStackTrace();
            showAlert("Startup Error", "Could not load initial data: " + ex.getMessage());
        }
    }

    private void refreshExpenses() {
        List<Expense> list = expenseManager.getAllExpenses();
        expenseObservableList.setAll(list);
    }

    private void updateChart(PieChart chart) {
        chart.getData().clear();
        var map = expenseManager.getCategoryTotals();
        for (var entry : map.entrySet()) {
            chart.getData().add(new PieChart.Data(entry.getKey(), entry.getValue()));
        }
    }

    private void showAlert(String title, String message) {
        Alert a = new Alert(Alert.AlertType.INFORMATION, message, ButtonType.OK);
        a.setHeaderText(title);
        a.showAndWait();
    }

    @Override
    public void stop() throws Exception {
        DatabaseHelper.close();
        super.stop();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
