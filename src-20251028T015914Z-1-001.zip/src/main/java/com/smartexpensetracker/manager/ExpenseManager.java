package com.smartexpensetracker.manager;

import com.smartexpensetracker.db.DatabaseHelper;
import com.smartexpensetracker.model.Expense;

import java.sql.*;
import java.util.*;

public class ExpenseManager {

    public void addExpense(Expense e) {
        String sql = "INSERT INTO expenses (user_id, amount, category, note, date) VALUES (?,?,?,?,?)";
        try {
            Connection c = DatabaseHelper.getConnection();
            if (c == null || c.isClosed()) throw new SQLException("No database connection available!");

            try (PreparedStatement ps = c.prepareStatement(sql)) {
                ps.setObject(1, null);
                ps.setDouble(2, e.getAmount());
                ps.setString(3, e.getCategory());
                ps.setString(4, e.getNote());
                ps.setDate(5, java.sql.Date.valueOf(e.getDate()));
                ps.executeUpdate();
            }
            System.out.println("✅ Expense added successfully: " + e.getCategory() + " - " + e.getAmount());
        } catch (SQLException ex) {
            ex.printStackTrace();
            throw new RuntimeException("Error adding expense: " + ex.getMessage());
        }
    }

    public List<Expense> getAllExpenses() {
        List<Expense> list = new ArrayList<>();
        String sql = "SELECT id, amount, category, note, date FROM expenses ORDER BY date DESC";

        try {
            Connection c = DatabaseHelper.getConnection();
            if (c == null || c.isClosed()) throw new SQLException("No database connection available!");

            try (PreparedStatement ps = c.prepareStatement(sql);
                 ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Expense e = new Expense();
                    e.setId(rs.getInt("id"));
                    e.setAmount(rs.getDouble("amount"));
                    e.setCategory(rs.getString("category"));
                    e.setNote(rs.getString("note"));
                    java.sql.Date d = rs.getDate("date");
                    if (d != null) e.setDate(d.toLocalDate());
                    list.add(e);
                }
            }
            System.out.println("✅ Loaded expenses: " + list.size());
        } catch (SQLException ex) {
            ex.printStackTrace();
            throw new RuntimeException("Error loading expenses: " + ex.getMessage());
        }
        return list;
    }

    public Map<String, Double> getCategoryTotals() {
        Map<String, Double> map = new LinkedHashMap<>();
        String sql = "SELECT category, SUM(amount) as total FROM expenses GROUP BY category";

        try {
            Connection c = DatabaseHelper.getConnection();
            if (c == null || c.isClosed()) throw new SQLException("No database connection available!");

            try (PreparedStatement ps = c.prepareStatement(sql);
                 ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    map.put(rs.getString("category"), rs.getDouble("total"));
                }
            }
            System.out.println("✅ Category totals loaded: " + map.size());
        } catch (SQLException ex) {
            ex.printStackTrace();
            throw new RuntimeException("Error fetching category totals: " + ex.getMessage());
        }
        return map;
    }
}
