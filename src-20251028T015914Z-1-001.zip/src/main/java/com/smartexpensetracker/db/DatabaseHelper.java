package com.smartexpensetracker.db;

import java.io.InputStream;
import java.sql.*;
import java.util.Properties;

/**
 * Handles MySQL database connection and initialization.
 * Ensures the connection is valid before use and prints helpful diagnostics.
 */
public class DatabaseHelper {
    private static Connection conn;

    public static void init() {
        try {
            if (conn != null && !conn.isClosed()) return;

            // --- Load config file ---
            Properties props = new Properties();
            InputStream in = DatabaseHelper.class.getClassLoader().getResourceAsStream("config.properties");
            if (in == null) {
                System.err.println("❌ ERROR: config.properties not found in /resources!");
                throw new RuntimeException("Missing config.properties");
            }
            props.load(in);

            String url = props.getProperty("db.url");
            String user = props.getProperty("db.user");
            String pass = props.getProperty("db.password");

            System.out.println("🔍 Attempting DB connection:");
            System.out.println("  URL: " + url);
            System.out.println("  USER: " + user);

            conn = DriverManager.getConnection(url, user, pass);
            System.out.println("✅ Database connection established!");

            // Optional — verify connection is valid
            if (!conn.isValid(2)) {
                throw new SQLException("Connection test failed — invalid connection!");
            }
            System.out.println("🔗 DB Connection valid: " + conn.isValid(2));

        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("❌ Failed to initialize DB: " + e.getMessage());
        }
    }

    public static Connection getConnection() throws SQLException {
        if (conn == null || conn.isClosed()) {
            throw new SQLException("Connection not initialized. Call DatabaseHelper.init() first.");
        }
        return conn;
    }

    public static void close() {
        try {
            if (conn != null && !conn.isClosed()) {
                conn.close();
                System.out.println("✅ Database connection closed.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
