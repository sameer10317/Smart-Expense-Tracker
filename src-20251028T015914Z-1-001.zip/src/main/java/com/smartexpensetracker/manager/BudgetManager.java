package com.smartexpensetracker.manager;

import com.smartexpensetracker.db.DatabaseHelper;
import com.smartexpensetracker.model.Budget;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class BudgetManager {

    public void addBudget(Budget b) {
        String sql = "INSERT INTO budgets (user_id, category, limit_amount) VALUES (?,?,?)";
        try (Connection c = DatabaseHelper.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setObject(1, null);
            ps.setString(2, b.getCategory());
            ps.setDouble(3, b.getLimitAmount());
            ps.executeUpdate();
        } catch (SQLException ex) {
            throw new RuntimeException(ex);
        }
    }

    public List<Budget> getAllBudgets() {
        String sql = "SELECT id, user_id, category, limit_amount FROM budgets";
        List<Budget> list = new ArrayList<>();
        try (Connection c = DatabaseHelper.getConnection();
             PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Budget b = new Budget();
                b.setId(rs.getInt("id"));
                b.setUserId(rs.getInt("user_id"));
                b.setCategory(rs.getString("category"));
                b.setLimitAmount(rs.getDouble("limit_amount"));
                list.add(b);
            }
        } catch (SQLException ex) {
            throw new RuntimeException(ex);
        }
        return list;
    }
}
